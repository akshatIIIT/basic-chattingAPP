const mongoose=require("mongoose");
const connect=mongoose.connect("mongodb://localhost:27017/admin");
connect.then(()=>{
    console.log("connection established");
})
.catch(()=>{
    console.log("some error occured");
});
const LoginSchema=new mongoose.Schema(
    {
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
});
const collection= new mongoose.model("users",LoginSchema);
module.exports=collection;