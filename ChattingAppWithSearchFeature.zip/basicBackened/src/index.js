require("dotenv").config();
const http=require("http");
const axios=require("axios");
const express=require("express");
const path=require("path");
const {Server}=require("socket.io");
const bcrypt=require("bcrypt");
const app=express();
const collection=require("./config");
const server=http.createServer(app);
const io = new Server(server);
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.set("view engine","ejs");
app.use(express.static("public"));
const openaiApiKey= process.env.OPENAI_API_KEY;

app.get("/",(req,res)=>{
    res.render("login");
});
app.get("/signup",(req,res)=>{
    res.render("signup");
});
app.get("/ask",(req,res)=>{
    res.render("ask");
})
app.post("/signup",async (req,res)=>{
    const data={
        name:req.body.username,
        password:req.body.password
    }
    const checkuser=await collection.findOne({name:data.name});
    if(checkuser){
        res.send("already registered");
    }
    else{
        const saltvalue=10;
        const hashedPassword= await bcrypt.hash(data.password,saltvalue);
        data.password=hashedPassword;
        const userdata= await collection.insertMany(data);
        res.redirect("/");
    }
});
app.post("/",async (req,res)=>{
    try{
        const check=await collection.findOne({name:req.body.username});
        if(!check){
            return res.redirect("/signup");
        }
        const isPassword=await bcrypt.compare(req.body.password,check.password);
        if(isPassword){
            res.render("home",{username:req.body.username});
        }
        else{
            res.send("Incorrect password");
        }
    }
    catch{
        res.send("wrong details");
    }
});
// connecting chatgpt api to this application
app.post("/ask",async (req,res)=>{
    const question=req.body.question;
    try{
        const response=await axios.post(
          'https://api.openai.com/v1/chat/completions',
          {
            model:"gpt-3.5-turbo",
            messages:[{role:'user',content:question}],
          },
          {
            headers:{
                "content-Type":"application/json",
                Authorization:`Bearer ${openaiApiKey}`,
            },
          }
        );
        const answer=response.data.choices[0].message.content;
        res.json({answer});
    }
    catch(error){
        console.error("Error:" ,error);
        res.status(500).json({error:"Something went wrong"});
    }
});
//SOCKET IO HANDLING
const users = [];
io.on('connection', (socket) => {
    console.log("A new user connected! Socket ID: ", socket.id);
    socket.broadcast.emit('MESSAGE', "A user has joined the chat");

    // Notify when someone leaves
    socket.on('disconnect', () => {
        io.emit('MESSAGE', "A user has left the chat");
    });

    // Listen for user messages and broadcast them
    socket.on("user_message", (data) => {
        const { username, message } = data;
        const fullMessage = `${username}: ${message}`;
        
        // Broadcast message to all clients, including the sender
        socket.broadcast.emit("MESSAGE", fullMessage);
    });
});
const PORT=5000;
server.listen(PORT,()=>{
    console.log(`server connected at port:${PORT}`);
})
